# Integrating Oracle DevCS with external Jenkins Server and IntelliJ IDE

## Getting Started
What you will need:
* Oracle Cloud Trial Account
* IntelliJ IDE
* Jenkins

### Lab: 100
This part of the lab will help you get started with an Oracle cloud trial acccount:
* Click on this URL [Oracle Cloud Trial Account](https://myservices.us.oraclecloud.com/mycloud/signup?language=en&sourceType=:ex:tb:::RC_PDMK171128P00097:DevOps_HOL&SC=:ex:tb:::RC_PDMK171128P00097:DevOps_HOL&pcode=PDMK171128P00097), and complete all the required steps to get your free Oracle Cloud Trial Account.
* You must wait to receive your account before continuing to the "Create an Autonomous Developer Cloud Service instance" section:

#### Create an Autonomous Developer Cloud Service instance:
* Go to [Oracle Cloud Service](https://cloud.oracle.com/home) homepage.
* Create an __Autonomous Developer Cloud Service Instance__
* Create a __Project__ within your Autonomous Developer Cloud Service instance.
* Go to the code section on the lefthand side and click on __create a new repository__.
* insert copying instructions from before 

### Lab: 200
#### In this lab you will setup GIT with your IntelliJ IDE. 
* Download provided Java Web Application. <--- insert link
* Download [Git](https://git-scm.com/downloads)
* Open IntelliJ and open the __project folder__ that you just downloaded.
* Go to __IntelliJ preferences --> Version Control --> Git__
* You are now going to configure the path to the Git executable. Your Git executable path should be: 
```
/usr/local/bin/git
```
If this does not work, open up the terminal and type in:
```
which git
```
This should give you the path to your git executable. 
* Click on __apply__ 
* Go back to your project and click on __code__.
* Create a __new__ repository 
* Refresh the page and click the "http" button. Copy this link as we will need it to allows our IntelliJ IDE to commit, push, and pull changes to our code repo.
* Go back to IntelliJ IDE and click on __VCS --> Checkout from Version Control --> Git__
* Insert copied Git URL from DevCS and paste into IntelliJ. Click on test and then enter your credentails that you used to log into your cloud tenancy. 
* Clone the repo and open the project within IntelliJ. From there go into the index.jsp file and change the output.
* Save your changes
* Click on __VCS --> Git --> Push__
* __Commit__ and __push__ your changes. Once that is complete go back to your DevCS project, click 'project' on the left hand side and see that your changes have been committed. 
* If you don't have Java and Git installed please do so before going onto the next step.
 * [Java](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
 * [Git](https://git-scm.com/downloads)

### Lab: 300
This part of the lab will help you create your external Jenkins web server and connect it via webhooks with Autonomous Developer Cloud Service. 
* Download [Jenkins](https://jenkins.io/download/) 2.149
* Jenkins will then ask for the __administration password__. To get this password type in the terminal
```
sudo cat /Users/Shared/Jenkins/Home/secrets/initialAdminPassword
```
* Click "install suggested plugins". This process may take a few minutes to complete. Until this is done feel free to browse Oracle's Autonomous Developer Cloud Services to make yourself familiar with all the different offerings. 
* Setup admin information and continue. 
* Go to __configure --> Global Tool Configuration__, install the following plugins:
  * Unleash Maven Plugin
  * Notification Plugin
  * Build Authorization Token Root Plugin
* Configure Git, Java, and Maven settings: Go to __Manage Jenkins --> Global Tool Configuration__
 * For Git give any name you want and then set your path to your git.exe. To find this path go into terminal and type in
 ```
 which git
 ```
 * For Java give any name you want and then set the path of JAVA_HOME. To find this path go into terminal and type in
 ```
 /usr/libexec/java_home
 ```
* Go to the Jenkins Dashboard page and click __create new jobs__ and or __new item__ to create a job. 
  * __Enter an item name__: AutoDevCS_JavaApp
  * __Job type__: Maven
  * Press __OK___
* In the __description__ field of the __general__ tab on the Configuration page, enter a desrciption of the job that you see fit.
* Click the __Source Code Management__ tab.
  * Select the __git__ options
  * Enter the Oracle Autonomous Developer Cloud Service Git repository URL.
  * In the __credentials__ section click __add-->Jenkins__ and provide your Oracle Autonomous Developer Cloud Service credentials. 
  * Click __Add__ when you are done. If you are receiving a red error please make sure you have entered your credentials correctly. The error message should disappear after Jenkins verifies your credentials. 
  * Note: Make sure that you select the credentials you have just created. 
* Click the __Build__ tab.
  * Root POM: __HelloWorld/pom.xml__
  * Goals and options: __clean install__
* Click the __Post-build Actions__ tab
  * Click the __Add post-build action__ button and select the __Archive the artifacts__ options.
  * You will now see a __Files to archive__ field enter: __HelloWorld/*.war__
* Click the __Build Triggers__ tab
  * Select the __Trigger builds remotely__ check box
  * In the __Authentication token__ field enter: __my_auth_token__
* Click __save__
* Go to your terminal and type the command:
```
ssh -R 80:localhost:8080 ssh.localhost.run
```
This will allows your external Jenkins server to connect to the internet. You can now log into your Jenkins server using the new url provided. 

### Lab: 400
This part of the lab will help you create and configure the webhooks that will allows our external Jenkins server and Oracle Autonomous Developer Cloud project to communicate. Congrats! You are almost done!
* In Oracle Autonomous Developer Cloud Service interface, open the project, and click __Administration --> Webhooks__ in the side bar.
  * Click __+ New Webhook__
    * __Type__: Select __Hudson/Jenkins - Build trigger__
    * __Name__: Enter __JenkinsBuildWebhook__ 
    * __Build Server Url__: Your jenkins URL: (eg: http://username.localhost.run)
    * __Job name__: __AutoDevCS_JavaApp__
    * __Build Server Security__: Select __Build Token Root Plugin__, the build will be triggered only if the Build Authorization Token Root plugin is installed on the Jenkins server. 
    * __Remote Build Token__: my_auth_token, the same token name that was specififed in the Jenkins job.
    * __Repository__: The repository you made in Oracle Autonomous Developer Cloud Service. 
    * Click __Done__
  * Select the webhook you just created and click __Test__
  If the configuration is correct you will see a green check mark. If it is not there will be a red x and you will need to go into the logs to debug. Once you see the green check mark, your webhook is ready to send a notification to the Jenkins server to run a build when any update is pushed to the specified Git repo.
  * In the webhooks page, click __+ New Webhook__
    * __Type__: Select __Jenkins - Notification Plugin__
    * __Name__: Enter __JenkinsGetNotification__ 
    * __Base Url__: Your jenkins URL: (eg: http://username.localhost.run)
    * Check the box that says __Ongoing Builds__ 
    * Click __Done__
    The webhook is now able to get notification from the Jenkins server when the build runs and is complete. 
* Copy the __JenkinsGetNotification__ webhook __URL__
  * Now go back to your Jenkins server. Open the __configure__ page for your job.
  * Click on the __Job Notifications__ tab
  * Select __Add Endpoint__
    * In the __URL__ field past the JenkinsGetNotification webhook URL that you copied earlier. 
    * You __DO NOT__ have to change any other fields.
  * Select __Save__

Now your Autonomous Developer Cloud Service and Jenkins server are ready to send and recieve notifications. 
* Go to your Autonomous Developer Cloud Service, on the side bar select __Code__
  * Go into the directory and change the output in __Index.jsp__
  * To do so, there is a pencil icon that allows you to update your code within Autonomous Developer Cloud Service. 
  * __Save__
* Go to the side bar and click project.
  * You should see a notification that you have pushed your code to the master.
* Go to your Jenkins server
  * On the main page you should see a build happening under __Build Executor Status__. The initial build may take some time to complete. If the build does not succeed you can select your Job and the specific build. In the build there is a log that you can read to debug if necessary. 

When the build is running, if you go back to your Autonomous Developer Cloud Service project.
* Go to __Projects__
* You should see that a __Tracked Build__ is running. 
  * Once the build succeeds you will see a __Build Success Notification__
  

When the build is complete, if you go back to your Autonomous Developer Cloud Service project.
* Go to __Projects__
* You should see that a __Tracked Build__ has ended with the status:__Success__. 

With a successful build, go back to the Jenkins server.
* In the __Build__ page of your __Job__.
* You can now download the build artifact and deploy it to your server or on Oracle Java Cloud Service.

# What next???!!?!?!
* [Deploying a Java EE application to a Java Cloud Service Instance](https://www.oracle.com/webfolder/technetwork/tutorials/obe/cloud/javaservice/JCS/eclipse_jcs/eclipse_jcs.html)
* [Deploying a Jenkins server on OCI](https://blogs.oracle.com/cloud-infrastructure/deploy-jenkins-on-oracle-cloud-infrastructure) 


  


    
  




  


# JavaWebApplication
